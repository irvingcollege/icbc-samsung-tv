ICBC Samsung Seller Office assets — PARTIAL SET

Background and screenshots come from the existing app, not generated imagery.
Screenshots: actual Chromium rendering at 1920x1080, with unchanged local app files and real catalog bytes forwarded by the HTTPS capture harness. Not captured on a physical Samsung TV. See capture-provenance.json.

Missing: official church logo source (SVG or high-resolution transparent PNG). The project cross icon is app artwork, not the official church logo. Therefore transparent-logo.png (1920x1080 RGBA) and full-color-icon.png (512x423) were not fabricated.

Every included image passed dimensions, format/mode and conservative decimal KB limits. See verification.json. This partial set is not a complete store submission.
