Actual application screenshots, captured in Chromium at 1920x1080.

01-watch-live-offline.png: Watch Live player showing the real church server's offline video slate. The media loads and plays, but it is an offline notice, not an active church broadcast.
02-archived-sermon-playing.png: Real Sunday Worship — October 11, 2026 video actively playing, with the application's playback controls visible.
03-archived-sermon-paused.png: Additional player state after selecting Pause through the application's normal control.

Unmodified existing app source. No synthetic catalog, sample video, mock player, edited UI, or postprocessed screenshots. Browser capture uses the HTML video fallback, not physical Samsung AVPlay. Local source files were virtually hosted at the church origin in Playwright; production media/catalog response bytes were forwarded through curl with TLS verification and the configured proxy. No files were deployed to the church server. Nothing was submitted to Samsung.

capture-provenance.json records media requests, playback states and capture time.
